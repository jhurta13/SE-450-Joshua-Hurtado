package model;

public enum MouseMode {
    DRAW,
    SELECT,
    MOVE
}
